define("ace/snippets/apache_conf",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "apache_conf";

});
